# Starry — native Android assistant app

Shared context for any coding agent working in this repo (Claude Code, Codex
CLI, Gemini CLI, Aider, OpenCode). Read this fully before changing code.
Keep it updated as the source of truth — when you finish a task, check it
off in "Next up" and add a line to "Decisions" if you made a judgment call.

## What this is

A personal AI assistant app, Kotlin + Jetpack Compose. Chat screen, calls
the Anthropic API for replies, stores history and reminders locally with
Room, voice in/out via Android's built-in SpeechRecognizer + TextToSpeech.
Companion to a web version (same name, same visual identity) built earlier
in the project — this native app exists specifically for background
operation and voice, which a browser page can't do.

## Hard constraints — do not relitigate these

- **No system-Assistant-app integration.** Replacing "Hey Google" or
  running on the always-on low-power DSP is out of scope. That requires
  registering as Android's default Assistant role, a much larger and more
  invasive project than this one. Don't suggest it as a quick addition.
- **Background mode costs battery, on purpose, visibly.** The foreground
  service (`voice/BackgroundListenService.kt`) is real background
  operation, not a trick — Android requires a persistent notification
  the entire time it runs, and continuous mic + API calls drain the
  battery. That's not a bug to "fix" by hiding the notification; it's a
  platform requirement. Don't try to make this silent or automatic.
- **Starry is always-dark.** Navy/brass palette (see Design tokens below)
  is a committed brand identity, not something that should follow system
  light/dark mode.

## Personality — don't flatten this back to generic

Starry's voice lives in one place: `StarryPersona.kt` (project root of the
Kotlin source, package `com.starry.app`). Both `ChatViewModel.kt` and
`BackgroundListenService.kt` build their system prompt from
`StarryPersona.CORE` — if you're touching how Starry talks, edit that file,
don't inline a new prompt string somewhere else; two assistants with
different voices in one app is a bug, not a feature.

The short version of what's in there: warm, informal, present — texts like
a friend, not a tool. Notices context (skipped meals, hours at the desk, a
frustrated or excited tone) and responds to *that*, not just the literal
question, without turning into a nag. Uses the person's name sometimes, not
every line. Stays honest under the warmth — no empty flattery, no fake
certainty, and if something sounds like real distress rather than a rough
day, it says so plainly and points toward a person, not itself.

That last part is a real constraint, same tier as the Hard Constraints
above: Starry is a warm presence *during work*, not a substitute for actual
support. Don't write prompts that have it try to carry more than that.

## Architecture

```
app/src/main/kotlin/com/starry/app/
  MainActivity.kt              entry point, sets Compose content
  StarryApplication.kt         Application class (currently empty, hook here for app-wide init)
  data/
    ChatMessageEntity.kt       Room entity: role, content, timestamp
    ReminderEntity.kt          Room entity: text, createdAt
    StarryDao.kt                MessageDao + ReminderDao (Flow-based reads)
    StarryDatabase.kt          Room database, singleton via getInstance(context)
  network/
    AnthropicClient.kt         OkHttp POST to api.anthropic.com/v1/messages, non-streaming
  voice/
    VoiceInputManager.kt       wraps android.speech.SpeechRecognizer
    VoiceOutputManager.kt      wraps android.speech.tts.TextToSpeech
    BackgroundListenService.kt foreground Service: listen -> AnthropicClient -> speak loop
  ui/
    ChatScreen.kt               the whole UI: message list, reminder chips, mic/voice/background buttons
    ChatViewModel.kt           owns UiState, talks to Room + AnthropicClient
    theme/Color.kt, Theme.kt   design tokens below, wired into MaterialTheme
```

## Design tokens

| Token | Hex | Use |
|---|---|---|
| Ink | `#11152B` | background |
| Panel | `#1B2044` | surfaces/cards |
| Paper | `#F2EFE4` | primary text |
| Dim | `#9BA3CF` | secondary text, inactive icons |
| Brass | `#C9A15C` | accent — active states, send button, primary |
| BrassInk | `#2A1F0A` | text on brass background |

Matches the web version's palette exactly. If you add UI, pull colors
from `ui/theme/Color.kt`, don't hardcode hex values inline.

## API notes

- Endpoint: `https://api.anthropic.com/v1/messages`, header `x-api-key`,
  `anthropic-version: 2023-06-01`.
- Model string is `claude-sonnet-5` in `AnthropicClient.kt` — this does
  change over time; check docs.claude.com if requests start failing with
  a model-not-found error before assuming the code is broken.
- Key comes from `local.properties` → `BuildConfig.ANTHROPIC_API_KEY`.
  Never hardcode a key in source. `local.properties` is gitignored.

## Current state

Builds (best-effort — written without a compiler in the loop, so expect
first-build errors: dependency version mismatches, a renamed API, that
kind of thing — normal, just fix forward).

Working: chat round-trip, Room persistence, mic input, spoken replies,
reminder chips (saved explicitly via `viewModel.saveReminder`, not yet
AI-triggered), background foreground-service listen loop.

## Next up (unchecked = not started)

- [ ] Get a clean `./gradlew assembleDebug` — fix whatever the compiler
      actually complains about; this file's code may have small errors.
- [ ] Wire reminders to an AI-triggered tool call (like the web version's
      `save_reminder`) instead of only explicit saves.
- [ ] Add streaming responses instead of one-shot request/response.
- [ ] Error states in the UI for background-service failures (mic busy,
      permission revoked mid-session, etc.) — currently fails silently
      and just stops listening.
- [ ] Real launcher icon + adaptive icon (currently using system default).

## Decisions log

- 2026: chose non-streaming API calls for v1 — simpler to get right than
  SSE parsing; streaming is an explicit Next Up item, not an oversight.
- 2026: reminders save explicitly rather than via tool-calling in v1, to
  keep the first working version's surface area small.

## Build / run

```
cp local.properties.example local.properties   # then fill in real values
./gradlew assembleDebug
```

No test suite yet. If you add one, document the run command here.
