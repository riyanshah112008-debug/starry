# Starry (native Android, v1)

A real Kotlin + Jetpack Compose starting point: chat screen, local history
and reminders via Room, calls to the Anthropic API, and voice in/out via
Android's built-in SpeechRecognizer + TextToSpeech.

This was written without a compiler in the loop (the environment I run in
has no Android SDK or network access), so treat it as a strong, carefully
reasoned first draft -- not guaranteed to build clean on the first try.
Small fixes (a dependency version bump, a renamed API) are exactly what
to hand Claude Code / Aider / whichever CLI you've got running once you
hit a real error message.

## What's deliberately simple in v1

- **Reminders are saved explicitly** (`viewModel.saveReminder(...)`), not
  yet via Starry deciding to call a tool mid-conversation like the web
  version does. Wiring that up is a good first task for a coding agent.
- **No streaming** -- one request, one full response. Streaming is a nice
  v2 once the basic round-trip is proven to work.
- **No login/auth flow** -- reads the API key from `local.properties`.

## Setup

1. Copy `local.properties.example` to `local.properties` and fill in a
   real `ANTHROPIC_API_KEY` from console.anthropic.com (usage-based
   billing, separate from a Claude subscription) and your `sdk.dir`.
   **`local.properties` is gitignored on purpose -- never commit it.**
2. Open the folder in Android Studio (File > Open), let Gradle sync, hit
   Run -- or from a terminal (including Termux, once the Android SDK /
   command-line tools are set up there): `./gradlew assembleDebug`.
3. First launch will ask for microphone permission when you tap the mic
   icon -- normal, that's the RECORD_AUDIO runtime permission.

## Where things live

```
app/src/main/kotlin/com/starry/app/
  MainActivity.kt          entry point
  data/                    Room entities + DAOs + database
  network/AnthropicClient  the API call (non-streaming)
  voice/                   SpeechRecognizer + TextToSpeech wrappers
  ui/                      ChatScreen (Compose) + ChatViewModel + theme
```

## Background mode (new)

Tap the bell icon (top bar) to start it. This runs a real foreground
Android service that keeps listening, thinking, and speaking while the
app is backgrounded or the screen's off. Two things Android requires,
not optional:

- A **persistent notification** stays up the entire time it's running
  (tap it to reopen the app, or hit Stop right in the notification).
- It **uses real battery** the whole time -- continuous mic + repeated
  API calls aren't free. It never starts on its own; you turn it on and
  off from the bell icon or the notification's Stop button.

What it still isn't: a true "Hey Starry" always-on wake word running on
negligible power. That requires registering as Android's system
Assistant app -- a separate, much bigger project. See AGENTS.md.

## Working with multiple coding agents on this repo

`AGENTS.md` is the shared project brief -- architecture, design tokens,
current state, and a "Next up" list to work through. `CLAUDE.md` and
`GEMINI.md` point back to it so Claude Code and Gemini CLI pick up the
same context; `.aider.conf.yml` does the same for Aider. Whichever CLI
you run, point it at this repo and it should have real context instead
of starting cold.
