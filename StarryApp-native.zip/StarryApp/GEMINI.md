See AGENTS.md in this repo root for full project context, constraints,
and current status. (Gemini CLI's auto-discovery of AGENTS.md wasn't
something I could verify for certain -- if this file isn't enough on its
own, check Gemini CLI's docs for its context-file setting and point it
at AGENTS.md directly.)
