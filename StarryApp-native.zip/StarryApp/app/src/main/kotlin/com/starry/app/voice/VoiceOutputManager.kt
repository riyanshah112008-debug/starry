package com.starry.app.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Wraps Android's built-in TextToSpeech. No special permission needed. */
class VoiceOutputManager(context: Context) {
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(context) { status ->
        ready = status == TextToSpeech.SUCCESS
    }

    fun speak(text: String) {
        if (!ready || text.isBlank()) return
        tts.language = Locale.getDefault()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "starry_reply")
    }

    fun stop() { tts.stop() }
    fun destroy() { tts.shutdown() }
}
