package com.starry.app

import android.app.Application

class StarryApplication : Application()
