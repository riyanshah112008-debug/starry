package com.starry.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ChatMessageEntity::class, ReminderEntity::class],
    version = 1,
    exportSchema = false
)
abstract class StarryDatabase : RoomDatabase() {
    abstract fun messageDao(): MessageDao
    abstract fun reminderDao(): ReminderDao

    companion object {
        @Volatile private var INSTANCE: StarryDatabase? = null

        fun getInstance(context: Context): StarryDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    StarryDatabase::class.java,
                    "starry.db"
                ).build().also { INSTANCE = it }
            }
    }
}
