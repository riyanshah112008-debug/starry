package com.starry.app.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.starry.app.BuildConfig
import com.starry.app.MainActivity
import com.starry.app.data.ChatMessageEntity
import com.starry.app.data.StarryDatabase
import com.starry.app.network.AnthropicClient
import com.starry.app.network.ChatTurn
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Keeps a listen -> think -> speak loop alive while the app is backgrounded
 * or the screen is off. This is real background operation, not a trick --
 * which also means it is NOT free. Android requires a persistent, visible
 * notification the whole time a foreground service runs (that's a platform
 * rule, not something this code can hide), and the mic + repeated API calls
 * cost real battery for as long as it's active.
 *
 * Started and stopped only by explicit user action from the app (see the
 * "Run in background" control in ChatScreen). Never starts itself, never
 * runs at boot, never listens without this notification showing.
 */
class BackgroundListenService : Service() {

    companion object {
        const val ACTION_START = "com.starry.app.action.START_BACKGROUND"
        const val ACTION_STOP = "com.starry.app.action.STOP_BACKGROUND"
        private const val CHANNEL_ID = "starry_background"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, BackgroundListenService::class.java).setAction(ACTION_START)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, BackgroundListenService::class.java).setAction(ACTION_STOP)
            )
        }
    }

    private val job = Job()
    private val scope = CoroutineScope(Dispatchers.Main + job)
    private var voiceInput: VoiceInputManager? = null
    private var voiceOutput: VoiceOutputManager? = null
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopLoop()
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification(), foregroundServiceType())
        startLoop()
        return START_NOT_STICKY
    }

    private fun foregroundServiceType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        else 0

    private fun startLoop() {
        if (running) return
        running = true
        voiceOutput = VoiceOutputManager(this)
        voiceInput = VoiceInputManager(
            context = this,
            onResult = { text -> handleUtterance(text) },
            onError = { if (running) listenAgain() },
            onListeningChange = { }
        )
        listenAgain()
    }

    private fun listenAgain() {
        if (running) voiceInput?.start()
    }

    private fun handleUtterance(text: String) {
        scope.launch {
            val db = StarryDatabase.getInstance(applicationContext)
            db.messageDao().insert(ChatMessageEntity(role = "user", content = text))

            val reminders = db.reminderDao().observeAll().first()
            val systemPrompt = buildString {
                append(com.starry.app.StarryPersona.CORE)
                append(com.starry.app.StarryPersona.SPOKEN_ADDENDUM)
                if (reminders.isNotEmpty()) {
                    append("\n\nThings they've asked you to remember: ")
                    append(reminders.joinToString("; ") { it.text })
                    append(".")
                }
            }
            val turns = db.messageDao().observeAll().first().takeLast(10).map {
                ChatTurn(if (it.role == "user") "user" else "assistant", it.content)
            }

            AnthropicClient(BuildConfig.ANTHROPIC_API_KEY)
                .sendMessage(turns, systemPrompt)
                .onSuccess { reply ->
                    db.messageDao().insert(ChatMessageEntity(role = "assistant", content = reply))
                    voiceOutput?.speak(reply)
                }
            listenAgain()
        }
    }

    private fun stopLoop() {
        running = false
        voiceInput?.stop()
        voiceInput?.destroy()
        voiceOutput?.stop()
        voiceOutput?.destroy()
    }

    private fun buildNotification(): Notification {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Starry background listening", NotificationManager.IMPORTANCE_LOW)
            )
        }

        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, BackgroundListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Starry is listening")
            .setContentText("Running in the background. Tap Stop to end this session.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        stopLoop()
        job.cancel()
        super.onDestroy()
    }
}
