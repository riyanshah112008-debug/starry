package com.starry.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.starry.app.BuildConfig
import com.starry.app.data.ChatMessageEntity
import com.starry.app.data.ReminderEntity
import com.starry.app.data.StarryDatabase
import com.starry.app.network.AnthropicClient
import com.starry.app.network.ChatTurn
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class ChatUiState(
    val messages: List<ChatMessageEntity> = emptyList(),
    val reminders: List<ReminderEntity> = emptyList(),
    val isSending: Boolean = false,
    val error: String? = null
)

class ChatViewModel(application: Application) : AndroidViewModel(application) {

    private val db = StarryDatabase.getInstance(application)
    private val client = AnthropicClient(BuildConfig.ANTHROPIC_API_KEY)

    private val _uiState = MutableStateFlow(ChatUiState())
    val uiState: StateFlow<ChatUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            db.messageDao().observeAll().collect { msgs ->
                _uiState.value = _uiState.value.copy(messages = msgs)
            }
        }
        viewModelScope.launch {
            db.reminderDao().observeAll().collect { reminders ->
                _uiState.value = _uiState.value.copy(reminders = reminders)
            }
        }
    }

    // Simple v1: reminders are saved explicitly, not via AI tool-calling yet.
    // Wiring Starry up to decide *when* to save one (like the web version's
    // save_reminder tool) is a good first task to hand a CLI coding agent.
    fun saveReminder(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            db.reminderDao().insert(ReminderEntity(text = text))
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank() || _uiState.value.isSending) return
        viewModelScope.launch {
            db.messageDao().insert(ChatMessageEntity(role = "user", content = text))
            _uiState.value = _uiState.value.copy(isSending = true, error = null)

            val reminders = db.reminderDao().observeAll().first()
            val systemPrompt = buildString {
                append(com.starry.app.StarryPersona.CORE)
                if (reminders.isNotEmpty()) {
                    append("\n\nThings they've asked you to remember: ")
                    append(reminders.joinToString("; ") { it.text })
                    append(".")
                }
            }

            val priorTurns = _uiState.value.messages.takeLast(20).map {
                ChatTurn(role = if (it.role == "user") "user" else "assistant", content = it.content)
            }
            val turns = priorTurns + ChatTurn("user", text)

            client.sendMessage(turns, systemPrompt)
                .onSuccess { reply ->
                    db.messageDao().insert(ChatMessageEntity(role = "assistant", content = reply))
                    _uiState.value = _uiState.value.copy(isSending = false)
                }
                .onFailure { e ->
                    _uiState.value = _uiState.value.copy(
                        isSending = false,
                        error = "Couldn't reach Starry's cloud brain: ${e.message}"
                    )
                }
        }
    }
}
