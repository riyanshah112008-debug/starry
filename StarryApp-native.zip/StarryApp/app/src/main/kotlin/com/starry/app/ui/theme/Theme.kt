package com.starry.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

// Starry is deliberately always-dark -- a committed brand identity,
// same as the web version, not something that follows system theme.
private val StarryColors = darkColorScheme(
    background = Ink,
    surface = Panel,
    primary = Brass,
    onPrimary = BrassInk,
    onBackground = Paper,
    onSurface = Paper,
    secondary = Dim,
    error = DangerColor
)

@Composable
fun StarryTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = StarryColors,
        content = content
    )
}
