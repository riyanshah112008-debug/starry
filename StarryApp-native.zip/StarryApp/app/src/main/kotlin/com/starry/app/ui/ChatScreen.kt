package com.starry.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.starry.app.voice.BackgroundListenService
import com.starry.app.voice.VoiceInputManager
import com.starry.app.voice.VoiceOutputManager
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(viewModel: ChatViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var voiceOutputEnabled by remember { mutableStateOf(false) }
    var listening by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    val voiceOutput = remember { VoiceOutputManager(context) }
    val voiceInput = remember {
        VoiceInputManager(
            context = context,
            onResult = { text -> viewModel.sendMessage(text) },
            onError = { /* surfaced via listening state only, keep v1 simple */ },
            onListeningChange = { listening = it }
        )
    }
    DisposableEffect(Unit) {
        onDispose {
            voiceInput.destroy()
            voiceOutput.destroy()
        }
    }

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) voiceInput.start() }

    var backgroundActive by remember { mutableStateOf(false) }
    val notificationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) { BackgroundListenService.start(context); backgroundActive = true } }

    fun toggleBackgroundMode() {
        if (backgroundActive) {
            BackgroundListenService.stop(context)
            backgroundActive = false
            return
        }
        val micGranted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (!micGranted) { micPermission.launch(Manifest.permission.RECORD_AUDIO); return }

        val needsNotifPermission = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needsNotifPermission) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        BackgroundListenService.start(context)
        backgroundActive = true
    }

    LaunchedEffect(state.messages.size) {
        if (state.messages.isNotEmpty()) {
            scope.launch { listState.animateScrollToItem(state.messages.size - 1) }
        }
    }

    // Speak Starry's replies aloud only when the toggle is on.
    LaunchedEffect(state.messages.lastOrNull()?.id, voiceOutputEnabled) {
        val last = state.messages.lastOrNull()
        if (last != null && last.role == "assistant" && voiceOutputEnabled) {
            voiceOutput.speak(last.content)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Starry") },
                actions = {
                    IconButton(onClick = { toggleBackgroundMode() }) {
                        Icon(
                            if (backgroundActive) Icons.Filled.Notifications else Icons.Filled.NotificationsOff,
                            contentDescription = if (backgroundActive) "Stop running in background" else "Run in background",
                            tint = if (backgroundActive) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.secondary
                        )
                    }
                    IconButton(onClick = { voiceOutputEnabled = !voiceOutputEnabled }) {
                        Icon(
                            Icons.Filled.VolumeUp,
                            contentDescription = "Toggle spoken replies",
                            tint = if (voiceOutputEnabled) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            )
        },
        bottomBar = {
            Column {
                if (state.reminders.isNotEmpty()) {
                    LazyRow(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        items(state.reminders, key = { it.id }) { reminder ->
                            AssistChip(
                                onClick = {},
                                label = { Text(reminder.text) },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = {
                        if (!voiceInput.isAvailable) return@IconButton
                        val granted = ContextCompat.checkSelfPermission(
                            context, Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) voiceInput.start() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    }) {
                        Icon(
                            Icons.Filled.Mic,
                            contentDescription = "Talk to Starry",
                            tint = if (listening) MaterialTheme.colorScheme.primary
                                   else MaterialTheme.colorScheme.secondary
                        )
                    }
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Message Starry…") },
                        singleLine = true
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = input.isNotBlank() && !state.isSending,
                        onClick = {
                            viewModel.sendMessage(input)
                            input = ""
                        }
                    ) { Text(if (state.isSending) "…" else "Send") }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(state.messages, key = { it.id }) { message ->
                MessageBubble(role = message.role, text = message.content)
            }
            state.error?.let { err ->
                item { Text(err, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}

@Composable
private fun MessageBubble(role: String, text: String) {
    val isUser = role == "user"
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Text(
            text = if (isUser) "you" else "starry",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.secondary
        )
        Text(text = text, style = MaterialTheme.typography.bodyLarge)
    }
}
