package com.starry.app.ui.theme

import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF11152B)
val Panel = Color(0xFF1B2044)
val Paper = Color(0xFFF2EFE4)
val Dim = Color(0xFF9BA3CF)
val Brass = Color(0xFFC9A15C)
val BrassInk = Color(0xFF2A1F0A)
val DangerColor = Color(0xFFE2847A)
