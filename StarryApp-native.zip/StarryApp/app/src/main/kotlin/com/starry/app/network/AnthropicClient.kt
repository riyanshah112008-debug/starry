package com.starry.app.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ChatTurn(val role: String, val content: String)

/**
 * Minimal client for the Anthropic Messages API.
 * Non-streaming for v1 -- simplest thing that can work end to end.
 * Model string: swap to "claude-haiku-5-5" for speed/cost, or
 * "claude-opus-5-5" for max capability. Check docs.claude.com for
 * the current roster before shipping -- these strings do change.
 */
class AnthropicClient(private val apiKey: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json".toMediaType()

    suspend fun sendMessage(turns: List<ChatTurn>, systemPrompt: String): Result<String> =
        withContext(Dispatchers.IO) {
            if (apiKey.isBlank()) {
                return@withContext Result.failure(
                    IOException("No ANTHROPIC_API_KEY set in local.properties")
                )
            }
            try {
                val messages = JSONArray()
                turns.forEach { turn ->
                    messages.put(
                        JSONObject()
                            .put("role", turn.role)
                            .put("content", turn.content)
                    )
                }

                val body = JSONObject()
                    .put("model", "claude-sonnet-5")
                    .put("max_tokens", 1024)
                    .put("system", systemPrompt)
                    .put("messages", messages)
                    .toString()
                    .toRequestBody(jsonMedia)

                val request = Request.Builder()
                    .url("https://api.anthropic.com/v1/messages")
                    .addHeader("x-api-key", apiKey)
                    .addHeader("anthropic-version", "2023-06-01")
                    .addHeader("content-type", "application/json")
                    .post(body)
                    .build()

                client.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext Result.failure(IOException("HTTP ${response.code}: $raw"))
                    }
                    val json = JSONObject(raw)
                    val content = json.optJSONArray("content")
                    val text = StringBuilder()
                    if (content != null) {
                        for (i in 0 until content.length()) {
                            val block = content.getJSONObject(i)
                            if (block.optString("type") == "text") {
                                text.append(block.optString("text"))
                            }
                        }
                    }
                    Result.success(text.toString())
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}
